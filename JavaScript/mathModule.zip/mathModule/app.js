var my_module = require('./mathlib')();

my_module.add(3,2);
my_module.multiply(3,2);
my_module.square(9);
my_module.random(2,30);